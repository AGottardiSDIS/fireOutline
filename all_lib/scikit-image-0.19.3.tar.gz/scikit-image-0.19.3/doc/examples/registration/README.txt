Image registration
------------------
