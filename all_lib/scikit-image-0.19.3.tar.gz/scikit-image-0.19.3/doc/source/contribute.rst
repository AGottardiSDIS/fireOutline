.. toctree:: 
   :hidden: 
 
   gitwash/index

.. include:: ../../CONTRIBUTING.txt
