#include <pythonic/core.hpp>
#include <pythonic/python/core.hpp>
#include <pythonic/types/bool.hpp>
#include <pythonic/types/int.hpp>
#ifdef _OPENMP
#include <omp.h>
#endif
#include <pythonic/include/types/numpy_texpr.hpp>
#include <pythonic/include/types/int64.hpp>
#include <pythonic/include/types/float64.hpp>
#include <pythonic/include/types/ndarray.hpp>
#include <pythonic/include/types/float32.hpp>
#include <pythonic/include/types/int32.hpp>
#include <pythonic/include/types/uint8.hpp>
#include <pythonic/types/numpy_texpr.hpp>
#include <pythonic/types/int64.hpp>
#include <pythonic/types/uint8.hpp>
#include <pythonic/types/int32.hpp>
#include <pythonic/types/float64.hpp>
#include <pythonic/types/ndarray.hpp>
#include <pythonic/types/float32.hpp>
#include <pythonic/include/builtins/None.hpp>
#include <pythonic/include/builtins/getattr.hpp>
#include <pythonic/include/builtins/range.hpp>
#include <pythonic/include/builtins/tuple.hpp>
#include <pythonic/include/operator_/add.hpp>
#include <pythonic/include/operator_/lt.hpp>
#include <pythonic/include/types/str.hpp>
#include <pythonic/builtins/None.hpp>
#include <pythonic/builtins/getattr.hpp>
#include <pythonic/builtins/range.hpp>
#include <pythonic/builtins/tuple.hpp>
#include <pythonic/operator_/add.hpp>
#include <pythonic/operator_/lt.hpp>
#include <pythonic/types/str.hpp>
namespace __pythran_brief_cy
{
  struct _brief_loop
  {
    typedef void callable;
    ;
    template <typename argument_type0 , typename argument_type1 , typename argument_type2 , typename argument_type3 , typename argument_type4 >
    struct type
    {
      typedef typename std::remove_cv<typename std::remove_reference<argument_type3>::type>::type __type0;
      typedef __type0 __type1;
      typedef typename std::remove_cv<typename std::remove_reference<decltype(pythonic::builtins::functor::range{})>::type>::type __type2;
      typedef decltype(pythonic::builtins::getattr(pythonic::types::attr::SHAPE{}, std::declval<__type1>())) __type4;
      typedef typename std::tuple_element<0,typename std::remove_reference<__type4>::type>::type __type5;
      typedef decltype(std::declval<__type2>()(std::declval<__type5>())) __type6;
      typedef typename std::remove_cv<typename std::iterator_traits<typename std::remove_reference<__type6>::type::iterator>::value_type>::type __type7;
      typedef __type7 __type8;
      typedef decltype(std::declval<__type1>()[std::declval<__type8>()]) __type9;
      typedef container<typename std::remove_reference<__type9>::type> __type10;
      typedef typename __combined<__type0,__type10>::type __type11;
      typedef __type9 __type12;
      typedef typename std::remove_cv<typename std::remove_reference<argument_type4>::type>::type __type13;
      typedef __type13 __type14;
      typedef decltype(std::declval<__type14>()[std::declval<__type8>()]) __type16;
      typedef container<typename std::remove_reference<__type16>::type> __type17;
      typedef typename __combined<__type13,__type17>::type __type18;
      typedef __type16 __type19;
      typedef pythonic::types::none_type __type20;
      typedef typename pythonic::returnable<__type20>::type __type21;
      typedef __type12 __ptype0;
      typedef __type19 __ptype1;
      typedef __type21 result_type;
    }  
    ;
    template <typename argument_type0 , typename argument_type1 , typename argument_type2 , typename argument_type3 , typename argument_type4 >
    inline
    typename type<argument_type0, argument_type1, argument_type2, argument_type3, argument_type4>::result_type operator()(argument_type0&& image, argument_type1&& descriptors, argument_type2&& keypoints, argument_type3&& pos0, argument_type4&& pos1) const
    ;
  }  ;
  template <typename argument_type0 , typename argument_type1 , typename argument_type2 , typename argument_type3 , typename argument_type4 >
  inline
  typename _brief_loop::type<argument_type0, argument_type1, argument_type2, argument_type3, argument_type4>::result_type _brief_loop::operator()(argument_type0&& image, argument_type1&& descriptors, argument_type2&& keypoints, argument_type3&& pos0, argument_type4&& pos1) const
  {
    {
      long  __target140475890196336 = std::get<0>(pythonic::builtins::getattr(pythonic::types::attr::SHAPE{}, pos0));
      for (long  p=0L; p < __target140475890196336; p += 1L)
      {
        typename pythonic::assignable_noescape<decltype(pos0[p])>::type __tuple0 = pos0[p];
        typename pythonic::assignable_noescape<decltype(std::get<0>(__tuple0))>::type pr0 = std::get<0>(__tuple0);
        typename pythonic::assignable_noescape<decltype(std::get<1>(__tuple0))>::type pc0 = std::get<1>(__tuple0);
        typename pythonic::assignable_noescape<decltype(pos1[p])>::type __tuple1 = pos1[p];
        typename pythonic::assignable_noescape<decltype(std::get<0>(__tuple1))>::type pr1 = std::get<0>(__tuple1);
        typename pythonic::assignable_noescape<decltype(std::get<1>(__tuple1))>::type pc1 = std::get<1>(__tuple1);
        {
          long  __target140475890024400 = std::get<0>(pythonic::builtins::getattr(pythonic::types::attr::SHAPE{}, keypoints));
          for (long  k=0L; k < __target140475890024400; k += 1L)
          {
            typename pythonic::assignable_noescape<decltype(keypoints[k])>::type __tuple2 = keypoints[k];
            typename pythonic::assignable_noescape<decltype(std::get<0>(__tuple2))>::type kr = std::get<0>(__tuple2);
            typename pythonic::assignable_noescape<decltype(std::get<1>(__tuple2))>::type kc = std::get<1>(__tuple2);
            if (pythonic::operator_::lt(image[pythonic::types::make_tuple(pythonic::operator_::add(kr, pr0), pythonic::operator_::add(kc, pc0))], image[pythonic::types::make_tuple(pythonic::operator_::add(kr, pr1), pythonic::operator_::add(kc, pc1))]))
            {
              descriptors[pythonic::types::make_tuple(k, p)] = true;
            }
          }
        }
      }
    }
    return pythonic::builtins::None;
  }
}
#include <pythonic/python/exception_handler.hpp>
#ifdef ENABLE_PYTHON_MODULE
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop0(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop1(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop2(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop3(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop4(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop5(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop6(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop7(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop8(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop9(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop10(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop11(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop12(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop13(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop14(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop15(pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop16(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop17(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop18(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop19(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop20(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop21(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop22(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop23(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop24(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop25(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop26(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop27(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop28(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop29(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop30(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop31(pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop32(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop33(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop34(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop35(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop36(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop37(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop38(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop39(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop40(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop41(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop42(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop43(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop44(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop45(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop46(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop47(pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop48(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop49(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop50(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop51(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop52(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop53(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop54(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop55(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop56(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop57(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop58(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop59(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop60(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop61(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>::result_type _brief_loop62(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}
inline
typename __pythran_brief_cy::_brief_loop::type<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>::result_type _brief_loop63(pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>&& image, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>&& descriptors, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>&& keypoints, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos0, pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>&& pos1) 
{
  
                            PyThreadState *_save = PyEval_SaveThread();
                            try {
                                auto res = __pythran_brief_cy::_brief_loop()(image, descriptors, keypoints, pos0, pos1);
                                PyEval_RestoreThread(_save);
                                return res;
                            }
                            catch(...) {
                                PyEval_RestoreThread(_save);
                                throw;
                            }
                            ;
}

static PyObject *
__pythran_wrap__brief_loop0(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop0(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop1(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop1(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop2(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop2(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop3(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop3(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop4(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop4(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop5(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop5(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop6(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop6(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop7(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop7(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop8(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop8(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop9(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop9(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop10(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop10(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop11(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop11(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop12(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop12(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop13(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop13(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop14(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop14(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop15(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop15(from_python<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop16(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop16(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop17(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop17(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop18(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop18(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop19(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop19(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop20(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop20(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop21(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop21(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop22(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop22(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop23(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop23(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop24(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop24(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop25(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop25(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop26(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop26(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop27(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop27(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop28(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop28(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop29(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop29(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop30(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop30(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop31(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop31(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<float,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop32(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop32(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop33(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop33(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop34(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop34(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop35(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop35(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop36(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop36(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop37(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop37(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop38(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop38(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop39(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop39(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop40(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop40(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop41(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop41(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop42(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop42(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop43(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop43(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop44(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop44(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop45(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop45(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop46(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop46(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop47(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop47(from_python<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop48(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop48(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop49(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop49(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop50(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop50(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop51(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop51(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop52(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop52(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop53(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop53(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop54(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop54(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop55(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop55(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop56(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop56(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop57(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop57(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop58(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop58(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop59(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop59(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop60(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop60(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop61(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop61(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop62(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4]))
        return to_python(_brief_loop62(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,std::integral_constant<long, 2>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

static PyObject *
__pythran_wrap__brief_loop63(PyObject *self, PyObject *args, PyObject *kw)
{
    PyObject* args_obj[5+1];
    
    char const* keywords[] = {"image", "descriptors", "keypoints", "pos0", "pos1",  nullptr};
    if(! PyArg_ParseTupleAndKeywords(args, kw, "OOOOO",
                                     (char**)keywords , &args_obj[0], &args_obj[1], &args_obj[2], &args_obj[3], &args_obj[4]))
        return nullptr;
    if(is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]) && is_convertible<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4]))
        return to_python(_brief_loop63(from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<double,pythonic::types::pshape<long,long>>>>(args_obj[0]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_uint8,pythonic::types::pshape<long,long>>>>(args_obj[1]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int64,pythonic::types::pshape<long,long>>>>(args_obj[2]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[3]), from_python<pythonic::types::numpy_texpr<pythonic::types::ndarray<npy_int32,pythonic::types::pshape<long,long>>>>(args_obj[4])));
    else {
        return nullptr;
    }
}

            static PyObject *
            __pythran_wrapall__brief_loop(PyObject *self, PyObject *args, PyObject *kw)
            {
                return pythonic::handle_python_exception([self, args, kw]()
                -> PyObject* {

if(PyObject* obj = __pythran_wrap__brief_loop0(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop1(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop2(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop3(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop4(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop5(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop6(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop7(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop8(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop9(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop10(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop11(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop12(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop13(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop14(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop15(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop16(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop17(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop18(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop19(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop20(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop21(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop22(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop23(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop24(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop25(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop26(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop27(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop28(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop29(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop30(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop31(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop32(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop33(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop34(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop35(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop36(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop37(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop38(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop39(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop40(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop41(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop42(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop43(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop44(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop45(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop46(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop47(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop48(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop49(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop50(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop51(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop52(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop53(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop54(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop55(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop56(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop57(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop58(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop59(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop60(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop61(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop62(self, args, kw))
    return obj;
PyErr_Clear();


if(PyObject* obj = __pythran_wrap__brief_loop63(self, args, kw))
    return obj;
PyErr_Clear();

                return pythonic::python::raise_invalid_argument(
                               "_brief_loop", "\n""    - _brief_loop(float32[:,:], uint8[:,:], int64[:,2], int32[:,2], int32[:,2])\n""    - _brief_loop(float64[:,:], uint8[:,:], int64[:,2], int32[:,2], int32[:,2])", args, kw);
                });
            }


static PyMethodDef Methods[] = {
    {
    "_brief_loop",
    (PyCFunction)__pythran_wrapall__brief_loop,
    METH_VARARGS | METH_KEYWORDS,
    "Supported prototypes:\n""\n""    - _brief_loop(float32[:,:], uint8[:,:], int64[:,2], int32[:,2], int32[:,2])\n""    - _brief_loop(float64[:,:], uint8[:,:], int64[:,2], int32[:,2], int32[:,2])"},
    {NULL, NULL, 0, NULL}
};


#if PY_MAJOR_VERSION >= 3
  static struct PyModuleDef moduledef = {
    PyModuleDef_HEAD_INIT,
    "brief_cy",            /* m_name */
    "",         /* m_doc */
    -1,                  /* m_size */
    Methods,             /* m_methods */
    NULL,                /* m_reload */
    NULL,                /* m_traverse */
    NULL,                /* m_clear */
    NULL,                /* m_free */
  };
#define PYTHRAN_RETURN return theModule
#define PYTHRAN_MODULE_INIT(s) PyInit_##s
#else
#define PYTHRAN_RETURN return
#define PYTHRAN_MODULE_INIT(s) init##s
#endif
PyMODINIT_FUNC
PYTHRAN_MODULE_INIT(brief_cy)(void)
#ifndef _WIN32
__attribute__ ((visibility("default")))
#if defined(GNUC) && !defined(__clang__)
__attribute__ ((externally_visible))
#endif
#endif
;
PyMODINIT_FUNC
PYTHRAN_MODULE_INIT(brief_cy)(void) {
    import_array()
    #if PY_MAJOR_VERSION >= 3
    PyObject* theModule = PyModule_Create(&moduledef);
    #else
    PyObject* theModule = Py_InitModule3("brief_cy",
                                         Methods,
                                         ""
    );
    #endif
    if(! theModule)
        PYTHRAN_RETURN;
    PyObject * theDoc = Py_BuildValue("(sss)",
                                      "0.11.0",
                                      "2022-06-12 18:11:03.151985",
                                      "3d6ed2c2416c15a3d8b52b3a8daeb884cfa03b338b833463d0ecba5600007b03");
    if(! theDoc)
        PYTHRAN_RETURN;
    PyModule_AddObject(theModule,
                       "__pythran__",
                       theDoc);


    PYTHRAN_RETURN;
}

#endif