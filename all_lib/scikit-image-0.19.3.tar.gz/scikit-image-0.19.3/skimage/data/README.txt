This directory contains sample data from scikit-image.

By default, it only contains a small subset of the entire dataset.

The full detaset can be downloaded by using the following commands from
a python console.

  >>> from skimage.data import download_all
  >>> download_all()
