"""
Version of sentinelhub package
"""

__version__ = "3.8.0"
